# mdpAgents.py
# parsons/20-nov-2017
#
# Version 1
#
# The starting point for CW2.
#
# Intended to work with the PacMan AI projects from:
#
# http://ai.berkeley.edu/
#
# These use a simple API that allow us to control Pacman's interaction with
# the environment adding a layer on top of the AI Berkeley code.
#
# As required by the licensing agreement for the PacMan AI we have:
#
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

# The agent here is was written by Simon Parsons, based on the code in
# pacmanAgents.py

from pacman import Directions
from game import Agent
import api
import random
import game
import util
import copy

class MDPAgent(Agent):

    # Constructor: this gets run when we first invoke pacman.py
    def __init__(self):
        print "Starting up MDPAgent!"
        name = "Pacman"

    # Gets run after an MDPAgent object is created and once there is
    # game state to access.
    def registerInitialState(self, state):
        print "Running registerInitialState for MDPAgent!"
        print "I'm at:"
        print api.whereAmI(state)

    # This is what gets run in between multiple games
    def final(self, state):
        print "Looks like the game just ended!"

    # For now I just move randomly
    def getAction(self, state):
        # Get the actions we can try, and remove "STOP" if that is one of them.
        legal = api.legalActions(state)
        if Directions.STOP in legal:
            legal.remove(Directions.STOP)
        # Random choice between the legal options.
        return api.makeMove(random.choice(legal), legal)

class Map(Agent):
    def positions(self, state):
        corners = api.corners(state)
        state = []
        for x in range(0, corners[1][0]+1):
            for y in range(0, corners[2][1]+1):

                state.append( (x, y) )

        states = dict.fromkeys(state, 0)

        return states

class moveMDP(Agent):

    def transitionModel(self, state, statesUCopy):
        # Probability of moving to the next state
        # Going straight = 0.8, right and left = 0.1

        pforward = 0.8
        pright = 0.1
        pleft = 0.1
        me = api.whereAmI(state)
        possibleRewards = self.lookAround(state, statesUCopy)

        # Move north from current state
        forwardNorth = pforward * possibleRewards[0]
        rightNorth = pright * possibleRewards[1]
        leftNorth = pleft * possibleRewards[3]

        northSummation = forwardNorth + rightNorth +  leftNorth

        # Move east from current state
        forwardEast = pforward * possibleRewards[1]
        downEast = pright * possibleRewards[2]
        upEast = pleft * possibleRewards[0]

        eastSummation = forwardEast + downEast + upEast

        # Move south from current state
        forwardSouth = pforward * possibleRewards[2]
        rightSouth = pright * possibleRewards[3] # Pacman facing south direction
        leftSouth = pleft * possibleRewards[1]

        southSummation = forwardSouth + rightSouth + leftSouth

        # Move west from current state
        forwardWest = pforward * possibleRewards[3]
        upWest = pright * possibleRewards[0]
        downWest = pleft * possibleRewards[2]

        westSummation = forwardWest + upWest + downWest

        maxDirs = northSummation + eastSummation + westSummation + southSummation
        maxRounded = round(maxDirs, 1)


        return maxRounded



    def lookAround(self, state, statesUCopy):
        # Add all possible movement positions in a list
        # Index 0: move up
        # Index 1: move right
        # Index 2: move down
        # Index 3: move left
        me = api.whereAmI(state)
        possibleRewards = [0, 0, 0, 0]
        if (me[0], me[1]+1) in statesUCopy:
            possibleRewards[0] = statesUCopy[(me[0], me[1] +1)]
        if (me[0]+1, me[1]) in statesUCopy:
            possibleRewards[1] = statesUCopy[(me[0] +1, me[1])]
        if (me[0], me[1]-1) in statesUCopy:
            possibleRewards[2] = statesUCopy[me[0], me[1]-1]
        if (me[0] -1, me[1]) in statesUCopy:
            possibleRewards[3] = statesUCopy[(me[0]-1, me[1])]
        return possibleRewards



    def setRewards(self, state):
        me = api.whereAmI(state)
        states = Map(Agent).positions(state)

        # Get ghost positions
        ghosts = api.ghostStatesWithTimes(state)
        # Get food positions
        food = api.food(state)

        # Get capsule positions
        capsules = api.capsules(state)

        # Get wall positions
        walls = api.walls(state)

        for s in states:
            if s in walls:
                states[s] = -10.0
            elif s in ghosts[1]:
                for g in ghosts:
                    if g[1] > 0:
                        states[s] = 8
                    else:
                        states[s] = -50.0
            elif s in food or capsules:
                states[s] = 10.0

            if (states[s] != -10.0 or states[s] != 10.0 or states[s] != -50.0 or states[s] != 8):
                discountFactor = -0.04
                statesUCopy = {}
                while (statesUCopy != states):
                    statesUCopy = copy.deepcopy(states)
                    states[s] = round(statesUCopy[s] + (discountFactor * self.transitionModel(state, statesUCopy)), 1)
        return states

    def lookAroundRewards(self, state, states, me):
        # Look in all possible directions of movement and pick maximum reward state

        north = (me[0], me[1]+1)
        east = (me[0] +1, me[1])
        south = (me[0], me[1]-1)
        west = (me[0]-1, me[1])

        if north in states:
            northDir = ('north', states[north])
        if east in states:
            eastDir = ('east', states[east])
        if south in states:
            southDir = ('south', states[south])
        if west in states:
            westDir = ('west', states[west])

        dirs = [northDir, eastDir, southDir, westDir]

        return dirs

    def getAction(self, state):
        me = api.whereAmI(state)
        legal = api.legalActions(state)
        food = api.food(state)


        states = self.setRewards(state)
        rewards = self.lookAroundRewards(state, states, me)
        maxRewards = max(rewards)
        print rewards
        print maxRewards

        if (maxRewards[0] == 'north'):
            return api.makeMove(Directions.NORTH, legal)
        elif (maxRewards[0] == 'east'):
            return api.makeMove(Directions.EAST, legal)
        elif (maxRewards[0] == 'south'):
            return api.makeMove(Directions.SOUTH, legal)
        elif (maxRewards[0] == 'west'):
            return api.makeMove(Directions.WEST, legal)
