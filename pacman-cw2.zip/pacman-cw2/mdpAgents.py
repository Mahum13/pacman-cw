# mdpAgents.py
# parsons/20-nov-2017
#
# Version 1
#
# The starting point for CW2.
#
# Intended to work with the PacMan AI projects from:
#
# http://ai.berkeley.edu/
#
# These use a simple API that allow us to control Pacman's interaction with
# the environment adding a layer on top of the AI Berkeley code.
#
# As required by the licensing agreement for the PacMan AI we have:
#
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).

# The agent here is was written by Simon Parsons, based on the code in
# pacmanAgents.py

from pacman import Directions
from game import Agent
import api
import random
from random import randint
import game
import util
import copy

class MDPAgent(Agent):

    def __init__(self):
        self.last = None

    def grid(self, state):

        corners = api.corners(state)
        x = corners[1][0] + 1
        y = corners[2][1] + 1
        if (y <= 7) and (x <= 7):
            return 'small'
        return 'medium'

    def getAction(self, state):
        me = api.whereAmI(state)
        legal = api.legalActions(state)
        if Directions.STOP in legal:
            legal.remove(Directions.STOP)

        gridSize = self.grid(state)
        states = self.states(state)
        # set up initial rewards and utilities
        rewardsInit = self.setRewardsInit(state, states)
        utsInit = self.setUtsInit(state, states)
        # set rewards according to what object is in state currently
        rewards = self.setRewards(state, rewardsInit, gridSize)
        # set utilities
        uts = self.setUts(state, utsInit, rewards, gridSize)
        # Once all utilities and rewards have been set, move according to state with highest utility
        maxUt = self.choseDirection(state, uts, me)

        if (maxUt == 0):
            self.last = 0
            return api.makeMove(Directions.NORTH, legal)
        elif (maxUt == 1):
            self.last = 1
            return api.makeMove(Directions.EAST, legal)
        elif (maxUt == 2):
            self.last = 2
            return api.makeMove(Directions.SOUTH, legal)
        elif (maxUt == 3):
            self.last = 3
            return api.makeMove(Directions.WEST, legal)

    def states(self, state):
        # Assign each state with a reward of 0
        corners = api.corners(state)
        states = []

        for x in range(corners[1][0]+1):
            for y in range(corners[2][1]+1):
                states.append( (x, y) )
        return states

    def setRewardsInit(self, state, states):
        # Set up grid with initial rewards to be zero
        statesRewards = {}
        for s in states:
            statesRewards[s] = 0
        return statesRewards

    def setUtsInit(self, state, states):
        # Set up grid with initial utilities to be zero
        statesUts = {}
        for s in states:
            statesUts[s] = 0

        ghosts = api.ghosts(state)

        for g in ghosts:
            statesUts[g] = -1.0
        return statesUts



    def setRewards(self, state, statesRewards, gridSize):
        if (gridSize == 'small'):
            scaryGhostReward = -5.0
            scaredGhostReward = 6.0
            foodCapsReward = 2.0
            emptyReward = 1.3
        elif (gridSize == 'medium'):
            scaryGhostReward = -11.0
            scaredGhostReward = 7.0
            foodCapsReward = 6.0
            emptyReward = 1.5

        # After initial set up, set rewards according to whether state has
        # a ghost, wall, food/capsule or is empty

        # Get ghost positions
        scaryGhosts = []
        scaredGhost = []
        ghosts = self.ghostToInt(state)
        for g in range(len(ghosts)):
            if (ghosts[g][1] > 3):
                scaredGhost.append( ghosts[g][0] )
            else:
                scaryGhosts.append(ghosts[g][0] )
        # Get wall positions
        walls = api.walls(state)

        # Get food and capsule positions
        food = api.food(state)
        capsule = api.capsules(state)

        for s in statesRewards:
            if s in walls:
                continue
            if s in scaryGhosts:
                statesRewards[s] = scaryGhostReward
            elif s in scaredGhost:
                statesRewards[s] = scaredGhostReward
            elif s in food or s in capsule:
                statesRewards[s] = foodCapsReward
            else:
                # If the state does not contain any of the above objectes - is empty
                statesRewards[s] = emptyReward
        return statesRewards

    def ghostToInt(self, state):
        ghosts = []
        ghost = api.ghostStatesWithTimes(state)
        for g in range(len(ghost)):
            x = int(ghost[g][0][0])
            y = int(ghost[g][0][1])
            z = ghost[g][1]
            ghosts.append(((x, y), z))

        return ghosts

    def setUts(self, state, statesUts, statesRewards, gridSize):
        if (gridSize == 'small'):
            discountFactor = 0.7
        elif (gridSize == 'medium'):
            discountFactor = 0.8
        ghosts = api.ghosts(state)
        statesUCopy = {}
        walls = api.walls(state)
        while (statesUCopy != statesUts):
            statesUCopy = copy.deepcopy(statesUts)
            for s in statesUts:
                if s in walls:
                    continue
                if s in ghosts:
                    continue
                else:
                    val = statesRewards[s] + (discountFactor * self.transitionModel(state, statesUCopy, s))
                    statesUts[s] = round(val, 3)
        return statesUts

    def transitionModel(self, state, statesUCopy, s):
        # Probability of moving to the next state
        # Going straight = 0.8, right and left = 0.1
        # Returns the maximum of all 4 directions
        possibleUts = self.possibleUts(state, statesUCopy, s)
        # Utilitiy of moving north
        northSummation = round(self.calculateUts(possibleUts[0], possibleUts[1], possibleUts[3]), 3)
        # Utilitiy of moving east
        eastSummation = round(self.calculateUts(possibleUts[1], possibleUts[2], possibleUts[0]), 3)
        # Utilitiy of moving south
        southSummation = round(self.calculateUts(possibleUts[2], possibleUts[3], possibleUts[1]), 3)
        # Utilitiy of moving west
        westSummation = round(self.calculateUts(possibleUts[3], possibleUts[0], possibleUts[2]), 3)

        maxDirs = [northSummation, eastSummation, westSummation, southSummation]
        return max(maxDirs)

    def possibleUts(self, state, statesUCopy, s):
        # Add all possible movement positions in a list
        # Index 0: move up
        # Index 1: move right
        # Index 2: move down
        # Index 3: move left
        walls = api.walls(state)
        north = (s[0], s[1]+1)
        east = (s[0]+1, s[1])
        south = (s[0], s[1]-1)
        west = (s[0]-1, s[1])

        possibleUts = [statesUCopy[s], statesUCopy[s], statesUCopy[s], statesUCopy[s]]

        if north in walls:
            possibleUts[0] = statesUCopy[s]
        else:
            possibleUts[0] = statesUCopy[north]
        if east in walls:
            possibleUts[1] = statesUCopy[s]
        else:
            possibleUts[1] = statesUCopy[east]
        if south in walls:
            possibleUts[2] = statesUCopy[s]
        else:
            possibleUts[2] = statesUCopy[south]
        if west in walls:
            possibleUts[3] = statesUCopy[s]
        else:
            possibleUts[3] = statesUCopy[west]
        return possibleUts



    def calculateUts(self, utForward, utSide1, utSide2):
        pforward = 0.8
        pside = 0.1
        val = (utForward * pforward) + (utSide1 * pside) + (utSide2 * pside)
        return round(val, 3)

    def choseDirection(self, state, statesUts, me):
        # Look in all possible directions of movement and pick maximum reward state
        # 0 = north
        # 1 = east
        # 2 = south
        # 3 = west
        walls = api.walls(state)
        north = (me[0], me[1]+1)
        east = (me[0] +1, me[1])
        south = (me[0], me[1]-1)
        west = (me[0]-1, me[1])
        dirs = [statesUts[me], statesUts[me], statesUts[me], statesUts[me]]

        legal = api.legalActions(state)
        if Directions.NORTH in legal:
            dirs[0] = statesUts[north]
        if Directions.EAST in legal:
            dirs[1] = statesUts[east]
        if Directions.SOUTH in legal:
            dirs[2] = statesUts[south]
        if Directions.WEST in legal:
            dirs[3] = statesUts[west]
        dirsMax = max(dirs)

        # if dirs.count(dirsMax > 1):# if dirs.index(dirsMax) == self.last or dirs.count(dirsMax) > 1:
        #     return self.last
        # else:
        #     return dirs.index(dirsMax)
        return dirs.index(dirsMax)
